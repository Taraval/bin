#!/bin/bash

arg_setup=$1

if [ "${arg_setup}" == "remove" ]; then
    rm ~/.tmux.conf
    rm ~/.vimrc
    rm ~/.vim
else
    ln -sfn ~/.dotfiles-linux/tmux.conf ~/.tmux.conf
    ln -sfn ~/.dotfiles-linux/vimrc ~/.vimrc
    ln -sfn  ~/.dotfiles-linux/vim ~/.vim
fi

